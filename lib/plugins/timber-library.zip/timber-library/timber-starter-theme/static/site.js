jQuery( document ).ready( function( $ ) {

  // Your JavaScript goes here

});